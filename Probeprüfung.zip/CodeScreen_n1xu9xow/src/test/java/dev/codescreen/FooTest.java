package dev.codescreen;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Add test cases for your coding test in here. All tests must use the Junit test framework.
 */
public class FooTest {

  @Test
  public void testBar1() {
    assertEquals(1, Foo.bar(1));
  }
}
