package dev.codescreen;

/**
 * Dummy class with a dummy method.
 * Rename this class and method to a name that is more appropriate to your coding test.
 */
public class Foo {

  /**
   * Example function that returns the number that is passed to it.
   *
   * @return number that is passed to it
   */
  public static int bar(int n) {
    return n;
  }

}
