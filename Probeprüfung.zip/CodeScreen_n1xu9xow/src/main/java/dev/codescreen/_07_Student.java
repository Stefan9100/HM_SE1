package dev.codescreen;

public class _07_Student {

    private String name;
    private String study;

    public _07_Student(String name, String study){
        this.name = name;
        this.study = study;
    }


    public String getStudy(){
        return study;
    }
    /*
     Studiert die Person Wirtschaftsinformatik,
     dann gibt es die folgende seltsame Regel:

     * Die Person kann ihr Fach nur zu Informatik
     * oder zu Wirtschaft wechseln.
     * versucht die Person das Fach zu etwas anders zu wechseln,
     * dann geschieht einfach nichts!

    Nun die seltsame Regeln gehen weiter!

    * Studiert die Person ein anderes Fach als Wirtschaftsinformatik
    * so kann die Person das Fach beliebig wechseln!
    * Beispiel: von Mathematik zu Physik!

     Implementieren Sie die Methode changeStudy gemäß der Regeln oben!

     */

    public void changeStudy(String study){
        // Hier kommt Ihr Code!
        if (this.getStudy().equals("Wirtschaftsinformatik")){
            if(study.equals("Informatik") ||study.equals("Wirtschaft")){
                this.study = study;
            }
        }
        else{
            this.study = study;
        }
    }




}
