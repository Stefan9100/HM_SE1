package dev.codescreen;

public class _06_Grad {

    /*
     Schreibe Sie eine Methode mit einer int Zahl als Argument.
     * ist die Zahl gleich 1, dann liefert die Methode "sehr gut"
     * ist die Zahl gleich 2, dann liefert die Methode "gut"
     * ist die Zahl gleich 3, dann liefert die Methode "befriedigend"
     * ist die Zahl gleich 4, dann liefert die Methode "ausreichend"
     * ist die Zahl gleich 5, dann liefert die Methode "nicht bestanden"
     * bei allen anderen Zahlen liefert die Methode: "unbekannt".
     * Nutzen Sie dafür nur switch - case
     */

    public static String evaluate(int n) {
        return switch (n) {
            case 1 -> "sehr gut";
            case 2 -> "gut";
            case 3 -> "befriedigend";
            case 4 -> "ausreichend";
            case 5 -> "nicht bestanden";
            default -> "unbekannt";
        };
    }

    public static void main(String[] args) {
        for(int i = 1; i < 7; i++){
            System.out.println(evaluate(i));
        }
    }
}
