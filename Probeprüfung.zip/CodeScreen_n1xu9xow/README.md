Probe Prüfung
## Submitting your solution

Please push your changes to the `main branch` of this repository. You can push one or more commits. <br>

Once you are finished with the task, please click the `Submit Solution` link on <a href="https://app.codescreen.com/candidate/cd1813a1-ec44-408b-9104-6263ec398471" target="_blank">this screen</a>.